# SGL
Trabajo Practico POO.
 - Sistema de Gestión de Laboratorio

    Acá vamos a ir dejando todo lo que vamos haciendo.
    
    Despues de hacer esto voy a liberar el proyecto y cada uno puede ponerlo en su repositorio propio para tener un portfolio.
