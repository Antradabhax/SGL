package dto;
import clases.Roles;

public class RolDto {
    private Roles Rol;

    public Roles getRol() {
        return Rol;
    }

    public void setRol(Roles rol) {
        Rol = rol;
    }
}
