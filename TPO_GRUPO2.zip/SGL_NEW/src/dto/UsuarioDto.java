package dto;

public class UsuarioDto {
    /*No utilizado mantener por si acaso*/
}
