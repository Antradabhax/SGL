package clases.ResultadoPractica;

public class ResultadoPracticaBooleano extends ResultadoPractica {
    private boolean valorResultado;

    public boolean isValorResultado() {
        return this.valorResultado;
    }

    public void setValorResultado(boolean valorResultado) {
        this.valorResultado = valorResultado;
    }

}