package clases.ResultadoPractica;

public class ResultadoPracticaCritico extends ResultadoPractica {
    private float resultado;

    public float getResultado() {
        return this.resultado;
    }

    public void setResultado(float resultado) {
        this.resultado = resultado;
    }

}
