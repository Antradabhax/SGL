package clases.ResultadoPractica;

import clases.TipoReserva;

public class ResultadoPractica {
    private TipoReserva confidencialidad;

    public TipoReserva getConfidencialidad() {
        return this.confidencialidad;
    }

    public void setConfidencialidad(TipoReserva confidencialidad) {
        this.confidencialidad = confidencialidad;
    }

}
