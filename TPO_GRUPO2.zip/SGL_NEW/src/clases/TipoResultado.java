package clases;

public enum TipoResultado {
    Critico,
    Booleano,
    Cadena
}
