package clases;

public enum TipoReserva {
    Reservado,
    NoReservado
}
