package clases;

public enum EstadoPractica {
    Finalizado,
    EnProceso
}
