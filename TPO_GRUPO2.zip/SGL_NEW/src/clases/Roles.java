package clases;

public enum Roles {
    Recepcion,
    Administrador,
    Laboratorista
}